import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-app.js";
import { getFirestore, collection, onSnapshot } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyAMWkuployP7Vx0p7PpxE_UgwjqxmjuaIk",
    authDomain: "maintain-36ddd.firebaseapp.com",
    projectId: "maintain-36ddd",
    storageBucket: "maintain-36ddd.firebasestorage.app",
    messagingSenderId: "513735623640",
    appId: "1:513735623640:web:00f8e8cf0e4419fa1028ad"
};

// Global State for Dashboard
window._dashboardState = {
    allProjects: [],
    filteredProjects: [],
    map: null,
    markers: [],
    selectedRoadLayers: [],
    activeBaseLayer: 'osm'
};

const davaoDeOroCenter = [7.6044, 125.9522];
const defaultZoom = 10;

// Initialize Firebase
let db;
try {
    const app = initializeApp(firebaseConfig);
    db = getFirestore(app);
} catch (err) {
    console.error('Firebase failed to initialize:', err);
}

document.addEventListener('DOMContentLoaded', function() {
    initMap();
    initFirestore();
    setupFilters();
    setupMapTools();
});

function initMap() {
    const map = L.map('map', {
        scrollWheelZoom: true,
        zoomControl: false 
    }).setView(davaoDeOroCenter, defaultZoom);

    L.control.zoom({ position: 'topleft' }).addTo(map);

    const osmLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
        maxZoom: 19,
        attribution: '© OpenStreetMap'
    });

    const satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
        maxZoom: 19,
        attribution: 'Tiles &copy; Esri'
    });

    osmLayer.addTo(map);
    window._dashboardState.map = map;
    window._dashboardState.layers = { osm: osmLayer, satellite: satelliteLayer };
}

function initFirestore() {
    if (!db) return;
    
    const projectColl = collection(db, "projects");
    const updatesColl = collection(db, "monthly_Updates"); // MUST match your JS exactly

    // Projects Listener
    onSnapshot(projectColl, (snapshot) => {
        const projects = [];
        snapshot.forEach(doc => projects.push({ id: doc.id, ...doc.data() }));
        window._dashboardState.allProjects = projects;
        updateMetricCards(); 
        renderRecentProjectsList();
        renderMarkers(); // Ensure markers update too
    });

    // NEW: Monthly Updates Listener
    onSnapshot(updatesColl, (snapshot) => {
    const updates = [];
    snapshot.forEach(doc => updates.push({ id: doc.id, ...doc.data() }));
    window._dashboardState.monthlyUpdates = updates;
    renderMonthlyUpdatesList();
});
}

function renderRecentProjectsList() {
    const container = document.getElementById('recentProjectsList');
    if (!container) return;

    const projects = window._dashboardState?.allProjects || [];
    const sorted = [...projects].sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

    let html = '';
    // Limit to 3. Reduced padding to remove "extra space".
    sorted.slice(0, 3).forEach(proj => {
        html += `
            <div class="record-row" style="display: grid; grid-template-columns: 2fr 1.2fr 0.8fr; padding: 22px 20px; border-bottom: 1px solid #f1f5f9; align-items: center;">
                <div class="col">
                    <div style="font-weight: 700; color: #1e293b; font-size: 1rem; line-height: 1.2;">${proj.title || '---'}</div>
                    <div style="font-size: 0.75rem; color: #94a3b8; margin-top: 4px;">ID: ${proj.id.substring(0, 8)}</div>
                </div>
                <div class="col" style="font-size: 0.85rem; color: #64748b; font-weight: 500;">${proj.engineer || '---'}</div>
                <div class="col" style="text-align: right;">
                    <span style="padding: 4px 10px; border-radius: 4px; font-size: 0.7rem; font-weight: 700; background: #f8fafc; color: #475569; border: 1px solid #e2e8f0;">
                        ${proj.status || 'ACTIVE'}
                    </span>
                </div>
            </div>`;
    });

    container.innerHTML = html || '<div style="padding: 20px; color: #94a3b8;">No projects found.</div>';
}

function renderMonthlyUpdatesList() {
    const container = document.getElementById('recentUpdatesList');
    if (!container) return;

    const allUpdates = window._dashboardState?.monthlyUpdates || [];
    const sorted = [...allUpdates].sort((a, b) => {
        const dateA = a.updateDate || "";
        const dateB = b.updateDate || "";
        return dateB.localeCompare(dateA); 
    });

    let html = '';
    sorted.slice(0, 5).forEach(upd => {
        const progressVal = upd.progress || 0;
        html += `
            <div style="padding: 12px 16px; border-bottom: 1px solid #f1f5f9; display: flex; align-items: center; gap: 12px;">
                <div style="flex-grow: 1;">
                    <div style="font-weight: 700; color: #1e293b; font-size: 0.85rem; line-height: 1.2;">
                        ${upd.projectTitle || 'Untitled Project'}
                    </div>
                    <div style="font-size: 0.75rem; color: #64748b; margin-top: 2px;">
                        Month ${upd.monthNumber || '--'} • ${upd.updateDate || 'No Date'}
                    </div>
                </div>
                <div style="text-align: right; min-width: 60px;">
                    <div style="font-size: 0.85rem; font-weight: 800; color: #0284c7;">
                        ${progressVal}%
                    </div>
                    <div style="width: 100%; height: 4px; background: #e2e8f0; border-radius: 2px; overflow: hidden; margin-top: 4px;">
                        <div style="width: ${progressVal}%; height: 100%; background: #0284c7;"></div>
                    </div>
                </div>
            </div>`;
    });

    container.innerHTML = html || '<div style="padding:20px;">No updates found.</div>';
}


function updateMetricCards() {
    const projects = window._dashboardState.allProjects;
    const total = projects.length;
    const ongoing = projects.filter(p => p.status === 'Ongoing').length;
    const completed = projects.filter(p => p.status === 'Completed').length;

    const totalEl = document.getElementById('totalProjectsVal');
    const ongoingEl = document.getElementById('ongoingProjectsVal');
    const completedEl = document.getElementById('completedProjectsVal');

    if (totalEl) totalEl.innerText = total;
    if (ongoingEl) ongoingEl.innerText = ongoing;
    if (completedEl) completedEl.innerText = completed;
}

function setupFilters() {
    ['municipalityFilter', 'statusFilter'].forEach(id => {
        document.getElementById(id)?.addEventListener('change', applyFilters);
    });
}

function applyFilters() {
    const muniVal = document.getElementById('municipalityFilter')?.value || "All";
    const statusVal = document.getElementById('statusFilter')?.value || "All";

    window._dashboardState.filteredProjects = window._dashboardState.allProjects.filter(p => {
        const matchMuni = muniVal === "All" || p.municipality === muniVal;
        const matchStatus = statusVal === "All" || p.status === statusVal;
        return matchMuni && matchStatus;
    });

    renderMarkers();
    closeProjectDetails();
}

function renderMarkers() {
    const { map, markers, filteredProjects } = window._dashboardState;
    
    // Clear existing markers
    markers.forEach(m => map.removeLayer(m));
    window._dashboardState.markers = [];

    // All road geometries are hidden initially as per request
    clearRoadGeometries();

    filteredProjects.forEach(p => {
        // Average coordinates if multiple roads, or just use first road's start if available
        let coords = [7.6044, 125.9522]; // Default fallback
        
        if (p.affectedRoads && p.affectedRoads.length > 0) {
            try {
                const firstRoad = p.affectedRoads[0];
                const geo = JSON.parse(firstRoad.geoJSON);
                const firstCoord = geo.geometry.coordinates[0];
                coords = [firstCoord[1], firstCoord[0]];
            } catch (e) {
                console.warn("Could not extract coordinates for project:", p.title);
            }
        } else {
            // Jitter for projects with no road data to avoid overlaps at center
            coords = [7.6044 + (Math.random() - 0.5) * 0.1, 125.9522 + (Math.random() - 0.5) * 0.1];
        }

        let color = '#FBBF24'; // Amber (Ongoing)
        if (p.status === 'Completed') color = '#10B981'; // Emerald (Completed)
        if (p.status === 'Terminated') color = '#EF4444'; // Red (Terminated)

        const customIcon = L.divIcon({
            className: 'project-marker-container',
            html: `<div class="project-marker-dot" style="background: ${color}; box-shadow: 0 0 0 4px ${color}33;"></div>`,
            iconSize: [20, 20],
            iconAnchor: [10, 10]
        });

        const marker = L.marker(coords, { icon: customIcon }).on('click', () => {
            handleProjectClick(p);
        }).addTo(map);

        window._dashboardState.markers.push(marker);
    });
}

function handleProjectClick(project) {
    const { map } = window._dashboardState;
    
    // 1. Clear previous roads
    clearRoadGeometries();

    // 2. Render road segments
    if (project.affectedRoads && project.affectedRoads.length > 0) {
        project.affectedRoads.forEach(road => {
            try {
                const geoJSON = JSON.parse(road.geoJSON);
                const layer = L.geoJSON(geoJSON, {
                    style: {
                        color: getStatusColor(project.status),
                        weight: 6,
                        opacity: 0.8,
                        lineCap: 'round'
                    }
                }).addTo(map);
                window._dashboardState.selectedRoadLayers.push(layer);
            } catch (e) {
                console.error("Error drawing road for project", e);
            }
        });

        // Fit map to show roads
        const group = new L.featureGroup(window._dashboardState.selectedRoadLayers);
        map.flyToBounds(group.getBounds(), { padding: [100, 100], duration: 1.5 });
    }

    // 3. Show glassmorphic details
    showProjectDetails(project);
}

function getStatusColor(status) {
    if (status === 'Completed') return '#10B981';
    if (status === 'Terminated') return '#EF4444';
    return '#FBBF24';
}

function clearRoadGeometries() {
    const { map, selectedRoadLayers } = window._dashboardState;
    selectedRoadLayers.forEach(layer => map.removeLayer(layer));
    window._dashboardState.selectedRoadLayers = [];
}

function showProjectDetails(project) {
    const details = document.getElementById('mapProjectDetails');
    if (!details) return;

    details.classList.remove('hidden');
    // Force a reflow for animation
    void details.offsetWidth;
    details.classList.add('active');

    // Fill data
    document.getElementById('detailProjectTitle').innerText = project.title;
    document.getElementById('detailMunicipality').innerText = project.municipality;
    document.getElementById('detailEngineer').innerText = project.engineer || 'Unassigned';
    document.getElementById('detailBudget').innerText = project.budget ? `₱${Number(project.budget).toLocaleString()}` : 'TBD';
    
    const start = project.startDate ? new Date(project.startDate).toLocaleDateString() : '---';
    const end = project.endDate ? new Date(project.endDate).toLocaleDateString() : '---';
    document.getElementById('detailTimeline').innerText = `${start} to ${end}`;

    const badge = document.getElementById('detailStatusBadge');
    badge.innerText = project.status;
    badge.className = `status-pill status-${(project.status || 'ongoing').toLowerCase()}`;

    const roadsList = document.getElementById('detailRoadsList');
    roadsList.innerHTML = '';
    if (project.affectedRoads && project.affectedRoads.length > 0) {
        project.affectedRoads.forEach(road => {
            const item = document.createElement('div');
            item.className = 'road-mini-item';
            item.innerHTML = `
                <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
                <span>${road.name}</span>
            `;
            roadsList.appendChild(item);
        });
    } else {
        roadsList.innerHTML = '<div class="no-roads">No linked assets</div>';
    }

    const viewFull = document.getElementById('detailViewFull');
    if (viewFull) {
        // Correct landing page based on context
        const isAdmin = window.location.pathname.includes('/Admin/');
        const targetPage = isAdmin ? 'AdminMaintenanceProject.php' : 'MaintenanceProject.php';
        viewFull.href = `${targetPage}?id=${project.id}`;
    }
}

function closeProjectDetails() {
    const details = document.getElementById('mapProjectDetails');
    if (details) {
        details.classList.remove('active');
        setTimeout(() => {
            if (!details.classList.contains('active')) details.classList.add('hidden');
        }, 300);
    }
    clearRoadGeometries();
}

function setupMapTools() {
    // Layer toggle
    document.getElementById('toggleLayerBtn')?.addEventListener('click', function() {
        const { layers, activeBaseLayer, map } = window._dashboardState;
        if (activeBaseLayer === 'osm') {
            map.removeLayer(layers.osm);
            layers.satellite.addTo(map);
            window._dashboardState.activeBaseLayer = 'satellite';
            document.getElementById('layerText').innerText = 'Switch to OSM';
        } else {
            map.removeLayer(layers.satellite);
            layers.osm.addTo(map);
            window._dashboardState.activeBaseLayer = 'osm';
            document.getElementById('layerText').innerText = 'Switch to Satellite';
        }
    });

    // Focus
    document.getElementById('focusBtn')?.addEventListener('click', function() {
        window._dashboardState.map.flyTo(davaoDeOroCenter, defaultZoom);
    });

    // Close details
    document.getElementById('closeMapDetails')?.addEventListener('click', closeProjectDetails);

    // Full Screen
    const btnFullScreen = document.getElementById('btnFullScreen');
    const mapArea = document.querySelector('.map-content-area');
    const fsText = document.getElementById('fullScreenText');

    btnFullScreen?.addEventListener('click', function() {
        if (!document.fullscreenElement) {
            mapArea.requestFullscreen().catch(err => console.error(err));
        } else {
            document.exitFullscreen();
        }
    });

    document.addEventListener('fullscreenchange', () => {
        const isFS = !!document.fullscreenElement;
        if (isFS) {
            fsText.innerText = 'Exit Full Screen';
            mapArea.classList.add('is-fullscreen');
        } else {
            fsText.innerText = 'Full Screen';
            mapArea.classList.remove('is-fullscreen');
        }
        setTimeout(() => window._dashboardState.map.invalidateSize(), 100);
    });


function isWithinLastThreeDays(createdAt) {
    if (!createdAt) return false;

    let projectDate;

    // 1. Check if it's a Firestore Timestamp with .toDate() method
    if (typeof createdAt.toDate === 'function') {
        projectDate = createdAt.toDate();
    } 
    // 2. Handle raw Timestamp object (seconds/nanoseconds)
    else if (createdAt.seconds) {
        projectDate = new Date(createdAt.seconds * 1000);
    } 
    // 3. Last resort fallback
    else {
        projectDate = new Date(createdAt);
    }

    if (isNaN(projectDate.getTime())) return false;

    const now = new Date();
    const threeDaysAgo = new Date();
    threeDaysAgo.setDate(now.getDate() - 3);

    // Return true if the project was created within the last 72 hours
    return projectDate >= threeDaysAgo;
}
}
