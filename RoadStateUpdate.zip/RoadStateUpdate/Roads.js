import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-app.js";
import { getFirestore, collection, addDoc, onSnapshot, deleteDoc, doc, updateDoc, query, orderBy, where, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyAMWkuployP7Vx0p7PpxE_UgwjqxmjuaIk",
    authDomain: "maintain-36ddd.firebaseapp.com",
    projectId: "maintain-36ddd",
    storageBucket: "maintain-36ddd.firebasestorage.app",
    messagingSenderId: "513735623640",
    appId: "1:513735623640:web:00f8e8cf0e4419fa1028ad"
};

// Global State
window._roadState = window._roadState || {
    allRoads: [],
    filteredRoads: [],
    currentPage: 1,
    currentRoadId: null,
    deleteMode: false,
    selectedRoads: new Set()
};

const itemsPerPage = 8;
let drawingMap = null;
let previewMap = null;
let drawnItems = null;

// Routing State
let startMarker = null;
let endMarker = null;
let routingControl = null;
let addingMode = 'none'; // 'start', 'end', or 'none'

// APP WRAPPER
let db;
try {
    const app = initializeApp(firebaseConfig);
    db = getFirestore(app);
} catch (err) {
    console.error('Firebase failed to initialize:', err);
}

const getFormOverlay = () => document.getElementById('roadFormModal');
const getDetailsOverlay = () => document.getElementById('roadDetailsModal');
const getTableBody = () => document.getElementById('roadsTableBody');

// --- EVENT DELEGATION ---
const setupDelegation = () => {
    if (window._roadClickHandler) {
        document.removeEventListener('click', window._roadClickHandler);
    }

    const handler = (e) => {
        // Open Modal (Add)
        const openBtn = e.target.closest('#btnAddNewRoad');
        if (openBtn) {
            openRoadForm();
        }

        // Close Modal
        const closeBtn = e.target.closest('#btnCloseRoadForm, #btnCancelRoadForm');
        if (closeBtn) {
            closeModals();
        }

        const closeDetailsBtn = e.target.closest('#btnCloseRoadDetails, #btnCloseDetailsBottom');
        if (closeDetailsBtn) {
            closeModals();
        }

        // Edit via Details
        const editFromDetails = e.target.closest('#btnEditRoadFromDetails');
        if (editFromDetails) {
            const id = window._roadState.currentRoadId;
            closeModals();
            setTimeout(() => {
                const road = window._roadState.allRoads.find(r => r.id === id);
                if (road) openRoadForm(road);
            }, 350);
        }

        // Mapping Controls
        const startBtn = e.target.closest('#btnSetStart');
        if (startBtn) {
            addingMode = 'start';
            const drawingMapEl = document.getElementById('drawingMap');
            if (drawingMapEl) drawingMapEl.style.cursor = 'crosshair';
            
            const guidance = document.getElementById('missionGuidance');
            if (guidance) guidance.innerText = 'MISSION: SELECT ROAD START POINT...';
            
            startBtn.classList.add('active');
            const endBtn = document.getElementById('btnSetEnd');
            if (endBtn) endBtn.classList.remove('active');
        }

        const endBtn = e.target.closest('#btnSetEnd');
        if (endBtn) {
            addingMode = 'end';
            const drawingMapEl = document.getElementById('drawingMap');
            if (drawingMapEl) drawingMapEl.style.cursor = 'crosshair';
            
            const guidance = document.getElementById('missionGuidance');
            if (guidance) guidance.innerText = 'MISSION: SELECT ROAD END POINT...';
            
            endBtn.classList.add('active');
            const startBtnEl = document.getElementById('btnSetStart');
            if (startBtnEl) startBtnEl.classList.remove('active');
        }

        // Fullscreen Logic
        const fsBtn = e.target.closest('#btnFullscreenMap');
        if (fsBtn) {
            const mapWrapper = fsBtn.closest('.map-wrapper');
            if (!document.fullscreenElement) {
                mapWrapper.requestFullscreen().then(() => {
                    mapWrapper.classList.add('roads-map-fullscreen');
                }).catch(err => {
                    console.error(`Error attempting to enable full-screen mode: ${err.message}`);
                });
            } else {
                document.exitFullscreen();
            }
        }

        // Refresh
        const refreshBtn = e.target.closest('#refreshBtn');
        if (refreshBtn) {
            const btnIcon = refreshBtn.querySelector('svg');
            if (btnIcon) {
                const currentRot = (parseInt(refreshBtn.dataset.rotation || '0')) + 360;
                refreshBtn.dataset.rotation = currentRot;
                btnIcon.style.transition = 'transform 0.6s cubic-bezier(0.4, 0, 0.2, 1)';
                btnIcon.style.transform = `rotate(${currentRot}deg)`;
            }
            applyFilters();
        }

        // Delete Mode Toggle
        const deleteModeBtn = e.target.closest('#deleteModeBtn');
        if (deleteModeBtn) {
            if (!window._roadState.deleteMode) {
                window._roadState.deleteMode = true;
                window._roadState.selectedRoads.clear();
                deleteModeBtn.classList.add('active');
                deleteModeBtn.querySelector('span').innerText = 'Confirm Delete (0)';
            } else {
                if (window._roadState.selectedRoads.size > 0) {
                    executeMultiDelete();
                } else {
                    exitDeleteMode();
                }
            }
            renderTable();
        }

        // Row Actions
        const viewBtn = e.target.closest('.view-btn');
        if (viewBtn && !viewBtn.hasAttribute('onclick')) {
            const id = viewBtn.dataset.id;
            const road = window._roadState.allRoads.find(r => r.id === id);
            if (road) openViewModal(road);
        }

        const editBtn = e.target.closest('.edit-btn');
        if (editBtn) {
            const id = editBtn.dataset.id;
            const road = window._roadState.allRoads.find(r => r.id === id);
            if (road) openRoadForm(road);
        }

        const deleteSelectBtn = e.target.closest('.delete-select-btn');
        if (deleteSelectBtn) {
            const id = deleteSelectBtn.dataset.id;
            if (window._roadState.selectedRoads.has(id)) {
                window._roadState.selectedRoads.delete(id);
            } else {
                window._roadState.selectedRoads.add(id);
            }
            const btnText = document.querySelector('#deleteModeBtn span');
            if (btnText) btnText.innerText = `Confirm Delete (${window._roadState.selectedRoads.size})`;
            renderTable();
        }
    };

    // Handing Exit Fullscreen class removal
    document.addEventListener('fullscreenchange', () => {
        if (!document.fullscreenElement) {
            const wrappers = document.querySelectorAll('.map-wrapper');
            wrappers.forEach(w => w.classList.remove('roads-map-fullscreen'));
        }
    });

    window._roadClickHandler = handler;
    document.addEventListener('click', handler);
};

setupDelegation();

// --- MAP CLICK HANDLER ---
const mapClickListener = (e) => {
    if (addingMode === 'start') {
        if (startMarker) drawingMap.removeLayer(startMarker);
        startMarker = L.marker(e.latlng, { draggable: true }).addTo(drawingMap);
        startMarker.on('dragend', updateRoute);
        document.getElementById('mapStartLat').value = e.latlng.lat;
        document.getElementById('mapStartLng').value = e.latlng.lng;
        addingMode = 'none';
        document.getElementById('drawingMap').style.cursor = 'grab';
        
        const guidance = document.getElementById('missionGuidance');
        if (guidance) guidance.innerText = 'START POINT LOCKED. SELECT END POINT.';
        
        document.getElementById('geojsonStatusText').innerText = 'Start point set. Select End point.';
        
        // Reset button borders if any
        const startBtn = document.getElementById('btnSetStart');
        if (startBtn) startBtn.classList.remove('active');
        updateRoute();
    } else if (addingMode === 'end') {
        if (endMarker) drawingMap.removeLayer(endMarker);
        endMarker = L.marker(e.latlng, { draggable: true }).addTo(drawingMap);
        endMarker.on('dragend', updateRoute);
        document.getElementById('mapEndLat').value = e.latlng.lat;
        document.getElementById('mapEndLng').value = e.latlng.lng;
        addingMode = 'none';
        document.getElementById('drawingMap').style.cursor = 'grab';
        
        const guidance = document.getElementById('missionGuidance');
        if (guidance) guidance.innerText = 'ROUTE ACQUISITION COMPLETE';
        
        document.getElementById('geojsonStatusText').innerText = 'Route captured!';
        
        // Reset button borders if any
        const endBtn = document.getElementById('btnSetEnd');
        if (endBtn) endBtn.classList.remove('active');
        updateRoute();
    }
};

function updateRoute() {
    if (startMarker && endMarker) {
        if (routingControl) drawingMap.removeControl(routingControl);
        
        routingControl = L.Routing.control({
            waypoints: [startMarker.getLatLng(), endMarker.getLatLng()],
            addWaypoints: false,
            draggableWaypoints: false,
            lineOptions: { styles: [{ color: '#78350F', opacity: 0.8, weight: 6 }] },
            show: false,
            createMarker: () => null
        }).addTo(drawingMap);

        // Hide the itinerary instructions container explicitly
        routingControl.on('routingstart', () => {
            const container = document.querySelector('.leaflet-routing-container');
            if (container) container.style.display = 'none';
        });

        routingControl.on('routesfound', function(e) {
            const route = e.routes[0];
            const distanceKm = (route.summary.totalDistance / 1000).toFixed(2);
            const geoJSON = {
                type: 'Feature',
                geometry: {
                    type: 'LineString',
                    coordinates: route.coordinates.map(c => [c.lng, c.lat])
                },
                properties: { 
                    distance: route.summary.totalDistance,
                    timestamp: new Date().toISOString()
                }
            };
            const roadNameVal = document.getElementById('roadName').value || "Segment";
            document.getElementById('roadGeoJSON').value = JSON.stringify(geoJSON);
            document.getElementById('geojsonStatus').classList.add('success');
            document.getElementById('geojsonStatusText').innerText = `${roadNameVal} | ${distanceKm} km captured`;
            
            const distVal = document.getElementById('totalDistance');
            if (distVal) distVal.innerText = `${distanceKm} km`;
            
            const guidance = document.getElementById('missionGuidance');
            if (guidance) guidance.innerText = `TERMINAL: ${distanceKm}KM CAPTURED`;

            // Re-hide container just in case it re-appeared
            const container = document.querySelector('.leaflet-routing-container');
            if (container) container.style.display = 'none';
        });
    }
}

// --- FIRESTORE ---
const initFirestoreListener = () => {
    if (!db) return;
    const roadColl = collection(db, "roads");
    onSnapshot(roadColl, (snapshot) => {
        window._roadState.allRoads = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        applyFilters();
    });
};

initFirestoreListener();

function applyFilters() {
    const muniVal = document.getElementById('filterMunicipality')?.value || "All";
    const paveVal = document.getElementById('filterPavement')?.value || "All";
    const sortVal = document.getElementById('filterSort')?.value || "Newest First";
    const searchVal = document.getElementById('roadSearch')?.value.toLowerCase() || "";

    window._roadState.filteredRoads = window._roadState.allRoads.filter(r => {
        const matchMuni = muniVal === "All" || r.municipality === muniVal;
        const matchPave = paveVal === "All" || r.pavementType === paveVal;
        const matchSearch = r.name.toLowerCase().includes(searchVal);
        return matchMuni && matchPave && matchSearch;
    });

    // Sorting
    window._roadState.filteredRoads.sort((a, b) => {
        const dateA = a.createdAt?.toDate?.() || a.createdAt || 0;
        const dateB = b.createdAt?.toDate?.() || b.createdAt || 0;
        if (sortVal === "A-Z") return a.name.localeCompare(b.name);
        if (sortVal === "Oldest First") return dateA - dateB;
        return dateB - dateA; // Newest
    });

    window._roadState.currentPage = 1;
    renderTable();
}

// Attach filter listeners
['filterMunicipality', 'filterPavement', 'filterSort'].forEach(id => {
    document.getElementById(id)?.addEventListener('change', applyFilters);
});
document.getElementById('roadSearch')?.addEventListener('input', applyFilters);

function renderTable() {
    const body = getTableBody();
    if (!body) return;
    body.innerHTML = '';

    const { filteredRoads, currentPage, deleteMode, selectedRoads } = window._roadState;
    if (filteredRoads.length === 0) {
        body.innerHTML = `<div class="records-placeholder">No road assets found matching filters.</div>`;
        document.getElementById('recordsNote').innerText = 'Showing 0 of 0 roads';
        return;
    }

    const start = (currentPage - 1) * itemsPerPage;
    const paginated = filteredRoads.slice(start, start + itemsPerPage);

    paginated.forEach(road => {
        const isSelected = selectedRoads.has(road.id);
        const row = document.createElement('div');
        row.className = `record-row ${isSelected ? 'to-delete' : ''}`;
        
        // Define columns: Added a new 1fr for the State column
        row.style.gridTemplateColumns = "2fr 1.3fr 0.8fr 0.8fr 1fr 0.8fr";

        let actionHtml = '';
        if (deleteMode) {
            actionHtml = `
                <button class="action-btn delete-select-btn ${isSelected ? 'selected' : ''}" data-id="${road.id}">
                    ${isSelected ? '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><polyline points="20 6 9 17 4 12"></polyline></svg>' : '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2" ry="2"></rect></svg>'}
                </button>
            `;
        } else {
            actionHtml = `
                <button type="button" class="action-btn view-btn" onclick="window.viewRecord('${road.id}')" title="View Details">
                    <i data-lucide="eye" style="width:20px; height:20px;"></i>
                </button>
                <button class="action-btn edit-btn" data-id="${road.id}" title="Edit">
                    <i data-lucide="pencil" style="width:18px; height:18px;"></i>
                </button>
            `;
        }

        // Added road.state to the output HTML template below
        row.innerHTML = `
            <div class="col">
                <div class="road-name-main">${road.name}</div>
                <div class="road-id-sub">SEC-${road.id.substring(0, 8).toUpperCase()}</div>
            </div>
            <div class="col font-medium">${road.municipality}</div>
            <div class="col font-medium">${road.state || '---'}</div>
            <div class="col">
                <span class="status-badge" style="background: #f1f5f9; color: #475569;">${road.pavementType}</span>
            </div>
            <div class="col">
                <div class="spatial-badge" style="display:flex; align-items:center; gap:6px; font-size:12px; font-weight:600; color:#059669;">
                   <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
                   Captured
                </div>
            </div>
            <div class="col actions-col" style="text-align: right;">
                ${actionHtml}
            </div>
        `;
        body.appendChild(row);
    });

    const actualEnd = Math.min(start + itemsPerPage, filteredRoads.length);
    document.getElementById('recordsNote').innerText = `Showing ${start + 1}-${actualEnd} of ${filteredRoads.length} roads`;
    if (window.lucide) lucide.createIcons();
}

// --- MODALS ---
function closeModals() {
    const form = getFormOverlay();
    const details = getDetailsOverlay();
    
    if (form) form.classList.remove('active');
    if (details) details.classList.remove('active');
    
    document.body.classList.remove('modal-open');
    setTimeout(() => {
        if (form) form.style.display = 'none';
        if (details) details.style.display = 'none';
    }, 300);
}

function openRoadForm(road = null) {
    const formOverlay = getFormOverlay();
    if (!formOverlay) return;

    window._roadState.currentRoadId = road ? road.id : null;
    
    const title = document.getElementById('roadFormTitle');
    const form = document.getElementById('roadForm');
    form.reset();
    
    document.getElementById('geojsonStatusText').innerText = 'No road geometry captured yet';
    document.getElementById('geojsonStatus').classList.remove('success');
    document.getElementById('roadGeoJSON').value = '';

    if (road) {
        title.innerText = "Edit Road Asset";
        document.getElementById('roadName').value = road.name;
        document.getElementById('roadMunicipality').value = road.municipality;
        const stateInput = document.getElementById('roadState');
        if (stateInput) stateInput.value = road.state || '';
        document.getElementById('pavementType').value = road.pavementType;
        document.getElementById('roadGeoJSON').value = road.geoJSON;
        document.getElementById('geojsonStatusText').innerText = 'Geometry loaded from database';
        document.getElementById('geojsonStatus').classList.add('success');
    } else {
        title.innerText = "New Road Asset Record";
    }

    formOverlay.style.display = 'flex';
    setTimeout(() => {
        formOverlay.classList.add('active');
        document.body.classList.add('modal-open');
    }, 10);

    // Drawing Map Logic
    setTimeout(() => {
        if (!drawingMap) {
            drawingMap = L.map('drawingMap').setView([7.6044, 125.9522], 11);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(drawingMap);
            drawingMap.on('click', mapClickListener);
            
            // Mouse tracking
            drawingMap.on('mousemove', (e) => {
                const latEl = document.getElementById('currentLat');
                const lngEl = document.getElementById('currentLng');
                if (latEl) latEl.innerText = e.latlng.lat.toFixed(6);
                if (lngEl) lngEl.innerText = e.latlng.lng.toFixed(6);
            });
        }
        
        const guidance = document.getElementById('missionGuidance');
        if (guidance) guidance.innerText = 'GIS TERMINAL ONLINE. SELECT START.';

        // Reset Markers & Controls
        if (startMarker) drawingMap.removeLayer(startMarker);
        if (endMarker) drawingMap.removeLayer(endMarker);
        if (routingControl) drawingMap.removeControl(routingControl);
        
        startMarker = null;
        endMarker = null;
        routingControl = null;
        addingMode = 'none';
        
        document.getElementById('drawingMap').style.cursor = 'grab';
        const startBtn = document.getElementById('btnSetStart');
        const endBtn = document.getElementById('btnSetEnd');
        if (startBtn) startBtn.classList.remove('active');
        if (endBtn) endBtn.classList.remove('active');

        const distVal = document.getElementById('totalDistance');
        if (distVal) distVal.innerText = `0.00 km`;

        if (road && road.geoJSON) {
            try {
                const geoData = JSON.parse(road.geoJSON);
                const coords = geoData.geometry.coordinates;
                const start = [coords[0][1], coords[0][0]];
                const end = [coords[coords.length-1][1], coords[coords.length-1][0]];
                
                startMarker = L.marker(start, { draggable: true }).addTo(drawingMap);
                endMarker = L.marker(end, { draggable: true }).addTo(drawingMap);
                startMarker.on('dragend', updateRoute);
                endMarker.on('dragend', updateRoute);
                
                updateRoute();
                setTimeout(() => {
                    drawingMap.invalidateSize();
                    drawingMap.fitBounds([start, end], { padding: [50, 50] });
                }, 150);
            } catch (e) {
                console.error("Error loading road geometry", e);
            }
        } else {
            drawingMap.invalidateSize();
        }
    }, 200);
}

window.viewRecord = (roadOrId) => {
    let road;
    if (typeof roadOrId === 'string') {
        road = window._roadState.allRoads.find(r => r.id === roadOrId);
    } else {
        road = roadOrId;
    }
    if (!road) return;
    openViewModal(road);
};

function openViewModal(road) {
    const detailsOverlay = getDetailsOverlay();
    if (!detailsOverlay) return;

    window._roadState.currentRoadId = road.id;

    // Standardized IDs for MP-style details
    const nameInput = document.getElementById('viewRoadName_input');
    const muniInput = document.getElementById('viewMunicipality_input');
    const stateInput = document.getElementById('viewRoadState_input');
    const paveInput = document.getElementById('viewPavementType_input');
    
    if (nameInput) nameInput.value = road.name;
    if (muniInput) muniInput.value = road.municipality || '---';
    if (stateInput) stateInput.value = road.state || '---';
    if (paveInput) paveInput.value = road.pavementType || '---';
    
    const idMeta = document.getElementById('viewRoadID_meta');
    const dateMeta = document.getElementById('viewCreatedAt_meta');
    
    if (idMeta) idMeta.innerText = `ID: SEC-${road.id.substring(0, 8).toUpperCase()}`;
    
    let createDate = "TBD";
    if (road.createdAt) {
        let d = road.createdAt;
        if (d && d.toDate) d = d.toDate();
        else if (d) d = new Date(d);
        if (d) createDate = d.toLocaleDateString();
    }
    if (dateMeta) dateMeta.innerText = `Added: ${createDate}`;

    detailsOverlay.style.display = 'flex';
    setTimeout(() => {
        detailsOverlay.classList.add('active');
        document.body.classList.add('modal-open');
    }, 10);

    // Preview Map
    setTimeout(() => {
        if (!previewMap) {
            previewMap = L.map('previewMap').setView([7.6044, 125.9522], 12);
            L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(previewMap);
        } else {
            previewMap.eachLayer(l => { if (l instanceof L.GeoJSON) previewMap.removeLayer(l); });
        }
        if (road.geoJSON) {
            try {
                const geoLayer = L.geoJSON(JSON.parse(road.geoJSON), { style: { color: '#78350F', weight: 5 } }).addTo(previewMap);
                previewMap.invalidateSize();
                
                const bounds = geoLayer.getBounds();
                previewMap.fitBounds(bounds, { padding: [20, 20] });

                // Lock to preview
                const paddedBounds = bounds.pad(0.5);
                previewMap.setMaxBounds(paddedBounds);
                previewMap.setMinZoom(previewMap.getBoundsZoom(paddedBounds) - 1);
                
                previewMap.on('drag', function() {
                    previewMap.panInsideBounds(paddedBounds, { animate: false });
                });
            } catch (e) {
                console.error("Error drawing preview map", e);
            }
        } else {
            previewMap.invalidateSize();
        }
    }, 200);
}

// --- FORM SUBMIT ---
document.getElementById('roadForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const btn = document.getElementById('btnSaveRoad');
    const spinner = document.getElementById('saveSpinner');
    const btnText = document.getElementById('btnSaveText');
    
    const geoJSON = document.getElementById('roadGeoJSON').value;
    if (!geoJSON) { alert("Please draw the road on the map first."); return; }

    const data = {
        name: document.getElementById('roadName').value,
        municipality: document.getElementById('roadMunicipality').value,
        state: document.getElementById('roadState')?.value || '', // Safely grabbing new state input value
        pavementType: document.getElementById('pavementType').value,
        geoJSON: geoJSON,
        updatedAt: serverTimestamp()
    };

    try {
        btn.disabled = true;
        spinner.classList.remove('hidden');
        btnText.innerText = "Saving...";

        if (window._roadState.currentRoadId) {
            await updateDoc(doc(db, "roads", window._roadState.currentRoadId), data);
        } else {
            data.createdAt = serverTimestamp();
            await addDoc(collection(db, "roads"), data);
        }
        closeModals();
    } catch (err) {
        console.error(err);
    } finally {
        btn.disabled = false;
        spinner.classList.add('hidden');
        btnText.innerText = window._roadState.currentRoadId ? "Apply Changes" : "Save Road Asset";
    }
});

// --- MULTI DELETE ---
function exitDeleteMode() {
    window._roadState.deleteMode = false;
    window._roadState.selectedRoads.clear();
    const btn = document.getElementById('deleteModeBtn');
    if (btn) {
        btn.classList.remove('active');
        btn.querySelector('span').innerText = 'Delete Road';
    }
}

async function executeMultiDelete() {
    const selectedIds = Array.from(window._roadState.selectedRoads);
    if (!confirm(`Permanently delete ${selectedIds.length} road assets?`)) return;

    const btn = document.getElementById('deleteModeBtn');
    btn.disabled = true;
    btn.querySelector('span').innerText = 'Deleting...';

    try {
        for (const id of selectedIds) {
            await deleteDoc(doc(db, "roads", id));
        }
        exitDeleteMode();
    } catch (err) {
        alert("Some deletions failed.");
    } finally {
        btn.disabled = false;
        renderTable();
    }
}