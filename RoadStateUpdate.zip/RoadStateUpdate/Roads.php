<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Roads Management | JAIROADS</title>
    <!-- CSS Dependencies -->
    <link rel="stylesheet" href="../../public/css/sidebar.css">
    <link rel="stylesheet" href="../../public/css/global.css">
    <link rel="stylesheet" href="../../public/css/AdminMaintenanceProject.css">
    <link rel="stylesheet" href="../../public/css/Roads.css">
    <link rel="stylesheet" href="../../public/css/RoadsForm.css">
    <link rel="stylesheet" href="../../public/css/AdminMPDetails.css">
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css" />
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.css" />
    <style>
        @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap');
    </style>
</head>
<body class="admin-view">

    <!-- Sidebar & Shared Assets -->
    <?php include __DIR__ . '/../partials/background.php'; ?>
    <?php include __DIR__ . '/../partials/adminSidebar.php'; ?>

    <main id="mainContent" class="main-content maintenance-page">
        <header class="top-nav-bar">
            <div class="header-title-section">
                <h1>Road Network Management</h1>
            </div>

            <div class="global-actions">
                <button class="btn-notification" title="Notifications">
                    <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
                </button>
                <button id="btnAddNewRoad" class="btn-quick-add">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"></line><line x1="5" y1="12" x2="19" y2="12"></line></svg>
                    <span>Add Road asset</span>
                </button>
                <button id="deleteModeBtn" class="btn-delete-toggle">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="3 6 5 6 21 6"></polyline><path d="M19 6v14a2 2 0 0 1-2 2H7a2 2 0 0 1-2-2V6m3 0V4a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2"></path><line x1="10" y1="11" x2="10" y2="17"></line><line x1="14" y1="11" x2="14" y2="17"></line></svg>
                    <span>Delete Road</span>
                </button>
            </div>
        </header>

        <div class="page-container">
            <!-- Filter Bar -->
            <section class="filter-shell">
                <div class="filter-search">
                    <svg class="filter-search-icon" width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                    <input type="text" id="roadSearch" placeholder="Search by road name...">
                </div>
                <div class="filter-actions">
                    <select id="filterMunicipality" class="filter-btn">
                        <option value="All">All Municipalities</option>
                        <option value="Compostela">Compostela</option>
                        <option value="Laak">Laak</option>
                        <option value="Mabini">Mabini</option>
                        <option value="Maco">Maco</option>
                        <option value="Maragusan">Maragusan</option>
                        <option value="Mawab">Mawab</option>
                        <option value="Monkayo">Monkayo</option>
                        <option value="Montevista">Montevista</option>
                        <option value="Nabunturan">Nabunturan</option>
                        <option value="New Bataan">New Bataan</option>
                        <option value="Pantukan">Pantukan</option>
                    </select>

                    <select id="filterPavement" class="filter-btn">
                        <option value="All">All Pavements</option>
                        <option value="Concrete">Concrete</option>
                        <option value="Asphalt">Asphalt</option>
                        <option value="Gravel">Gravel</option>
                        <option value="Earth">Earth</option>
                    </select>

                    <select id="filterSort" class="filter-btn">
                        <option value="Newest First">Newest First</option>
                        <option value="Oldest First">Oldest First</option>
                        <option value="A-Z">A - Z</option>
                    </select>

                    <button id="refreshBtn" class="refresh-btn" type="button">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 12a9 9 0 1 1-9-9c2.52 0 4.93 1 6.74 2.74L21 8"></path><path d="M21 3v5h-5"></path></svg>
                    </button>
                </div>
            </section>

            <!-- Table Section -->
            <section class="records-shell">
                <div class="records-head">
                    <div class="head-col">Road Name</div>
                    <div class="head-col">Municipality</div>
                    <div class="head-col">Pavement Type</div>
                    <div class="head-col">Spatial Data</div>
                    <div class="head-col actions-col" style="text-align: right;">Actions</div>
                </div>

                <div id="roadsTableBody" class="records-body">
                    <div class="records-placeholder">
                        Loading provincial road network...
                    </div>
                </div>

                <div class="records-footer">
                    <p id="recordsNote" class="records-note">Showing 0 roads</p>
                </div>
            </section>
        </div>
    </main>

    <!-- Modals -->
    <?php include __DIR__ . '/../components/forms/RoadsForm.php'; ?>
    <?php include __DIR__ . '/../components/modal/RoadsDetails.php'; ?>

    <!-- JS Dependencies -->
    <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/leaflet.draw/1.0.4/leaflet.draw.js"></script>
    <script src="https://unpkg.com/leaflet-routing-machine@latest/dist/leaflet-routing-machine.js"></script>
    <script type="module" src="../../public/js/pages/Roads.js"></script>

</body>
</html>
