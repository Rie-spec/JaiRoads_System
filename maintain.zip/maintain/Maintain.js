// maintenance-projects.js

import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-app.js";
import { getFirestore, collection, addDoc, doc, updateDoc, onSnapshot, query, orderBy } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyAMWkuployP7Vx0p7PpxE_UgwjqxmjuaIk",
    authDomain: "maintain-36ddd.firebaseapp.com",
    projectId: "maintain-36ddd",
    storageBucket: "maintain-36ddd.firebasestorage.app",
    messagingSenderId: "513735623640",
    appId: "1:513735623640:web:00f8e8cf0e4419fa1028ad"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

let allProjects = [];
let filteredProjects = [];
let currentPage = 1;
const itemsPerPage = 5;
let currentEditId = null;

const tableBody = document.getElementById('recordsBody');
const recordsNote = document.getElementById('recordsNote');
const paginationControls = document.getElementById('paginationControls');
const filterStatus = document.getElementById('filterStatus');
const filterMunicipality = document.getElementById('filterMunicipality');
const tableSearch = document.getElementById('tableSearch');
const overlay = document.getElementById('projectModalOverlay');

lucide.createIcons();

document.getElementById('openModalBtn').addEventListener('click', () => {
    currentEditId = null;
    document.getElementById('modalMainTitle').innerText = 'New Maintenance Project';
    document.getElementById('modalSubTitle').innerText = 'RECORD ENTRY FORM';
    document.querySelector('#saveProjectBtn span').innerText = 'SAVE PROJECT ENTRY';
    
    document.getElementById('formTitle').value = '';
    document.getElementById('formMunicipality').value = '';
    document.getElementById('formStart').value = '';
    document.getElementById('formEnd').value = '';
    document.getElementById('formEngineer').value = '';
    document.getElementById('formStatus').value = 'Ongoing';
    
    document.getElementById('metaContainer').style.display = 'none';
    document.getElementById('viewStatusBadge').style.display = 'none';
    
    overlay.classList.add('active');
    overlay.classList.remove('view-mode');
});

const closeModals = () => overlay.classList.remove('active');
document.getElementById('closeModalBtn').addEventListener('click', closeModals);
document.getElementById('cancelModalBtn').addEventListener('click', () => {
    if (currentEditId) {
        overlay.classList.add('view-mode');
    } else {
        closeModals();
    }
});
document.getElementById('refreshBtn').addEventListener('click', () => { location.reload(); });

document.getElementById('toggleEditBtn').addEventListener('click', () => {
    overlay.classList.remove('view-mode');
});

function formatDateRange(start, end) {
    if (!start || !end) return "TBD";
    const d1 = new Date(start);
    const d2 = new Date(end);
    return `${d1.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })} - ${d2.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`;
}

function getStatusBadge(status) {
    const st = (status || "").toLowerCase();
    if (st === 'ongoing') return 'status-ongoing';
    if (st === 'terminated') return 'status-terminated';
    if (st === 'completed') return 'status-completed';
    return 'status-ongoing'; 
}

const q = query(collection(db, "projects"), orderBy("createdAt", "desc"));
onSnapshot(q, (snapshot) => {
    allProjects = [];
    snapshot.forEach((doc) => {
        allProjects.push({ id: doc.id, ...doc.data() });
    });
    applyFilters();
});

function applyFilters() {
    const statusVal = filterStatus.value;
    const muniVal = filterMunicipality.value;
    const searchVal = tableSearch.value.toLowerCase();

    filteredProjects = allProjects.filter(p => {
        const matchStatus = statusVal === "All" || p.status === statusVal;
        const matchMuni = muniVal === "All" || p.municipality === muniVal;
        const matchSearch = (p.title || "").toLowerCase().includes(searchVal);
        return matchStatus && matchMuni && matchSearch;
    });

    currentPage = 1; 
    renderTable();
}

filterStatus.addEventListener('change', applyFilters);
filterMunicipality.addEventListener('change', applyFilters);
tableSearch.addEventListener('input', applyFilters);

function renderTable() {
    tableBody.innerHTML = '';

    if (filteredProjects.length === 0) {
        tableBody.innerHTML = `<div class="records-placeholder">No projects found.</div>`;
        recordsNote.innerText = `SHOWING 0 OF 0 PROJECTS`;
        paginationControls.innerHTML = '';
        return;
    }

    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const paginatedItems = filteredProjects.slice(startIndex, endIndex);

    paginatedItems.forEach(proj => {
        const row = document.createElement('div');
        row.className = 'record-row';
        
        row.innerHTML = `
            <div class="col">
                <div class="proj-name-main">${proj.title}</div>
                <div class="proj-id-sub">ID: ${proj.id.substring(0,8)}</div>
            </div>
            <div class="col font-medium">${proj.municipality}</div>
            <div class="col">
                <span class="status-badge ${getStatusBadge(proj.status)}">${proj.status}</span>
            </div>
            <div class="col">${proj.engineer || 'Unassigned'}</div>
            <div class="col">${formatDateRange(proj.startDate, proj.endDate)}</div>
            <div class="col actions-col" style="text-align: right;">
                <button class="action-btn view-btn" title="View Details">
                    <i data-lucide="eye" style="width: 18px; height: 18px;"></i>
                </button>
            </div>
        `;
        
        row.querySelector('.view-btn').addEventListener('click', () => {
            openViewModal(proj);
        });

        tableBody.appendChild(row);
    });

    lucide.createIcons();
    const actualEnd = Math.min(endIndex, filteredProjects.length);
    recordsNote.innerText = `SHOWING ${startIndex + 1} - ${actualEnd} OF ${filteredProjects.length} PROJECTS`;
    renderPagination();
}

function openViewModal(proj) {
    currentEditId = proj.id;
    
    document.getElementById('formTitle').value = proj.title || '';
    document.getElementById('formMunicipality').value = proj.municipality || '';
    document.getElementById('formStart').value = proj.startDate || '';
    document.getElementById('formEnd').value = proj.endDate || '';
    document.getElementById('formEngineer').value = proj.engineer || '';
    document.getElementById('formStatus').value = proj.status || 'Ongoing';

    document.getElementById('modalMainTitle').innerText = 'Maintenance Project Details';
    document.getElementById('modalSubTitle').innerText = 'RECORD OVERVIEW PANEL';
    document.querySelector('#saveProjectBtn span').innerText = 'APPLY CHANGES';

    document.getElementById('metaContainer').style.display = 'flex';
    
    let createDate = "TBD";
    if (proj.createdAt) {
        let d = proj.createdAt;
        if (d.toDate) { d = d.toDate(); } 
        else { d = new Date(d); }
        createDate = d.toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    }
    document.getElementById('metaDate').innerText = `Date: ${createDate}`;
    
    const topBadge = document.getElementById('viewStatusBadge');
    topBadge.style.display = 'inline-block';
    topBadge.className = `status-badge ${getStatusBadge(proj.status)}`;
    topBadge.innerText = proj.status ? proj.status.toUpperCase() : "ONGOING";

    const lastEditedSpan = document.getElementById('metaLastEdited');
    if (proj.updatedAt) {
        let uD = proj.updatedAt;
        if (uD.toDate) { uD = uD.toDate(); }
        else { uD = new Date(uD); }
        lastEditedSpan.innerText = `• EDITED ${uD.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' })}`;
    } else {
        lastEditedSpan.innerText = "";
    }

    overlay.classList.add('active', 'view-mode');
}

function renderPagination() {
    paginationControls.innerHTML = '';
    const totalPages = Math.ceil(filteredProjects.length / itemsPerPage);
    if (totalPages <= 1) return;

    const prevBtn = document.createElement('button');
    prevBtn.className = 'page-btn';
    prevBtn.innerHTML = `<i data-lucide="chevron-left"></i>`;
    prevBtn.disabled = currentPage === 1;
    prevBtn.onclick = () => { currentPage--; renderTable(); };
    paginationControls.appendChild(prevBtn);

    for (let i = 1; i <= totalPages; i++) {
        const btn = document.createElement('button');
        btn.className = `page-btn ${i === currentPage ? 'active' : ''}`;
        btn.innerText = i;
        btn.onclick = () => { currentPage = i; renderTable(); };
        paginationControls.appendChild(btn);
    }

    const nextBtn = document.createElement('button');
    nextBtn.className = 'page-btn';
    nextBtn.innerHTML = `<i data-lucide="chevron-right"></i>`;
    nextBtn.disabled = currentPage === totalPages;
    nextBtn.onclick = () => { currentPage++; renderTable(); };
    paginationControls.appendChild(nextBtn);

    lucide.createIcons();
}

document.getElementById('saveProjectBtn').addEventListener('click', async (e) => {
    const btn = e.currentTarget;
    const originalText = btn.innerHTML;
    btn.innerHTML = '<span>Saving...</span>';
    btn.disabled = true;

    const title = document.getElementById('formTitle').value;
    const muni = document.getElementById('formMunicipality').value;
    
    if (!title || !muni) {
        alert("Please fill in Title and Municipality.");
        btn.innerHTML = originalText;
        btn.disabled = false;
        return;
    }

    const projectData = {
        title: title,
        municipality: muni,
        startDate: document.getElementById('formStart').value,
        endDate: document.getElementById('formEnd').value,
        status: document.getElementById('formStatus').value,
        engineer: document.getElementById('formEngineer').value,
        updatedAt: Date.now() 
    };

    try {
        if (currentEditId) {
            await updateDoc(doc(db, "projects", currentEditId), projectData);
            openViewModal({id: currentEditId, ...projectData, updatedAt: Date.now()}); 
        } else {
            projectData.createdAt = Date.now();
            await addDoc(collection(db, "projects"), projectData);
            closeModals();
        }
    } catch (err) {
        console.error("Error: ", err);
    } finally {
        btn.innerHTML = originalText;
        btn.disabled = false;
    }
});