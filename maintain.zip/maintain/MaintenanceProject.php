<?php
$current_page = 'maintenance_projects';
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>JAIROADS - Maintenance Projects</title>

    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800;900&display=swap" rel="stylesheet">
    <script src="https://unpkg.com/lucide@latest"></script>
    
    <link rel="stylesheet" href="/CSS/PageLayout.css">
    <link rel="stylesheet" href="Maintenance.css">
</head>
<body>

    <div class="page-layout">
        
        <aside class="sidebar">
            <div class="sidebar-top">
                <div class="brand-row">
                    <div class="brand-icon-box">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12h14M12 5l7 7-7 7"/></svg>
                    </div>
                    <div class="brand-name">JAIROADS</div>
                </div>

                <div class="search-box">
                    <svg class="search-icon icon-left" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
                    <input type="text" placeholder="Search projects...">
                </div>

                <div class="sidebar-label">Infrastructure Hub</div>
                <nav class="sidebar-nav">
                    <a href="Dashboard.php" class="nav-item <?php echo ($current_page == 'dashboard') ? 'active' : ''; ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
                        <span>Dashboard</span>
                    </a>
                    <a href="MaintenanceProjects.php" class="nav-item <?php echo ($current_page == 'maintenance_projects') ? 'active' : ''; ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"></path></svg>
                        <span>Maintenance Projects</span>
                    </a>
                    <a href="WeeklyUpdates.php" class="nav-item <?php echo ($current_page == 'weekly_updates') ? 'active' : ''; ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
                        <span>Weekly Updates</span>
                    </a>
                    <a href="ProjectDocuments.php" class="nav-item <?php echo ($current_page == 'project_documents') ? 'active' : ''; ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
                        <span>Project Documents</span>
                    </a>
                    <a href="Roads.php" class="nav-item <?php echo ($current_page == 'roads') ? 'active' : ''; ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"></path><polyline points="9 22 9 12 15 12 15 22"></polyline></svg>
                        <span>Roads</span>
                    </a>
                    <a href="Engineers.php" class="nav-item <?php echo ($current_page == 'engineers') ? 'active' : ''; ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
                        <span>Engineers</span>
                    </a>
                    <a href="LGUs.php" class="nav-item <?php echo ($current_page == 'lgus') ? 'active' : ''; ?>">
                        <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="12 2 2 7 12 12 22 7 12 2"></polygon><polyline points="2 17 12 22 22 17"></polyline><polyline points="2 12 17 22 12"></polyline></svg>
                        <span>LGUs</span>
                    </a>
                </nav>
            </div>

            <div class="sidebar-footer">
                <div class="profile-card">
                    <div class="profile-avatar">JD</div>
                    <div class="profile-text">
                        <div class="profile-name">Jairus John Claude...</div>
                        <div class="profile-role">Engineer</div>
                    </div>
                </div>
                <button class="logout-btn">
                    <svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"></path><polyline points="16 17 21 12 16 7"></polyline><line x1="21" y1="12" x2="9" y2="12"></line></svg>
                    <span>Logout</span>
                </button>
            </div>
        </aside>

        <main class="main-content">
            <section class="page-heading-row">
                <div class="page-heading-text">
                    <h2 class="page-main-title">Maintenance Projects</h2>
                    <p class="page-subtitle" style="text-transform: uppercase;">Davao De Oro Region</p>
                </div>
                <button id="openModalBtn" class="primary-btn" type="button">
                    <i data-lucide="plus"></i><span>Add Maintenance Project</span>
                </button>
            </section>

            <section class="filter-shell">
                <div class="filter-search">
                    <i class="filter-search-icon" data-lucide="search"></i>
                    <input type="text" id="tableSearch" placeholder="Search by project title...">
                </div>
                <div class="filter-actions">
                    <select id="filterMunicipality" class="filter-btn">
                        <option value="All">All Municipalities</option>
                        <option value="Compostela">Compostela</option>
                        <option value="Laak">Laak</option>
                        <option value="Mabini">Mabini</option>
                        <option value="Maco">Maco</option>
                        <option value="Maragusan">Maragusan</option>
                        <option value="Mawab">Mawab</option>
                        <option value="Monkayo">Monkayo</option>
                        <option value="Montevista">Montevista</option>
                        <option value="Nabunturan">Nabunturan</option>
                        <option value="New Bataan">New Bataan</option>
                        <option value="Pantukan">Pantukan</option>
                    </select>

                    <select id="filterStatus" class="filter-btn">
                        <option value="All">All Statuses</option>
                        <option value="Completed">Completed</option>
                        <option value="Ongoing">Ongoing</option>
                        <option value="Terminated">Terminated</option>
                    </select>

                    <select class="filter-btn">
                        <option>All Assigned Engineers</option>
                    </select>

                    <button id="refreshBtn" class="refresh-btn" type="button">
                        <i data-lucide="rotate-cw"></i>
                    </button>
                </div>
            </section>

            <section class="records-shell">
                <div class="records-head">
                    <div class="head-col">Project Title</div>
                    <div class="head-col">Municipality</div>
                    <div class="head-col">Status</div>
                    <div class="head-col">Engineer</div>
                    <div class="head-col">Timeline</div>
                    <div class="head-col actions-col" style="text-align: right;">Actions</div>
                </div>

                <div id="recordsBody" class="records-body">
                    <div class="records-placeholder">
                        Place your records here. No projects found.
                    </div>
                </div>

                <div class="records-footer">
                    <p id="recordsNote" class="records-note">Showing 0 of 0 projects</p>
                    <div id="paginationControls" class="pagination"></div>
                </div>
            </section>
        </main>
    </div>

    <div id="projectModalOverlay" class="modal-overlay">
        <div class="modal-card">
            
            <div class="m-head">
                <div class="m-titlebox">
                    <div class="m-badge">
                        <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z"></path><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15 12a3 3 0 11-6 0 3 3 0 016 0z"></path></svg>
                    </div>
                    <div>
                        <h1 class="m-title" id="modalMainTitle">Maintenance Project Details</h1>
                        <p class="m-sub" id="modalSubTitle">RECORD OVERVIEW PANEL</p>
                    </div>
                </div>
                
                <div class="action-btn-group">
                    <button id="closeModalBtn" class="m-close">
                        <svg width="24" height="24" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M6 18L18 6M6 6l12 12"></path></svg>
                    </button>
                </div>
            </div>

            <div class="sect" id="titleSection">
                <span id="viewStatusBadge" class="status-badge" style="display:none; margin-bottom: 12px;"></span>
                <input id="formTitle" type="text" placeholder="Project Title" class="m-inp">
                
                <div class="modal-meta-container" id="metaContainer" style="display:none;">
                    <div class="modal-meta-item">
                        <i data-lucide="user" style="width:14px;height:14px;"></i>
                        <span id="metaCreator">Created by: Andrei Jacob</span>
                    </div>
                    <div class="modal-meta-item">
                        <i data-lucide="calendar" style="width:14px;height:14px;"></i>
                        <span id="metaDate">Date: April 25, 2026</span>
                    </div>
                    <span id="metaLastEdited" class="modal-last-edited"></span>

                </div>
            </div>

            <div class="sect">
                <div class="secthead">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    <span>PROJECT INFORMATION</span>
                </div>
                <div class="grid2">
                    <div>
                        <label class="lbl">MUNICIPALITY</label>
                        <select id="formMunicipality" class="m-inp">
                            <option value="">Select Municipality</option>
                            <option value="Compostela">Compostela</option>
                            <option value="Laak">Laak</option>
                            <option value="Mabini">Mabini</option>
                            <option value="Maco">Maco</option>
                            <option value="Maragusan">Maragusan</option>
                            <option value="Mawab">Mawab</option>
                            <option value="Monkayo">Monkayo</option>
                            <option value="Montevista">Montevista</option>
                            <option value="Nabunturan">Nabunturan</option>
                            <option value="New Bataan">New Bataan</option>
                            <option value="Pantukan">Pantukan</option>
                        </select>
                    </div>
                    <div>
                        <label class="lbl">ASSIGNED ENGINEER</label>
                        <div class="m-wrap left">
                            <svg class="m-icon l" width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z"></path></svg>
                            <input id="formEngineer" type="text" placeholder="Search Engineer" class="m-inp">
                        </div>
                    </div>
                </div>
            </div>

            <div class="sect">
                <div class="grid2">
                    <div>
                        <div class="secthead">
                            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>
                            <span>SCHEDULE</span>
                        </div>
                        <div class="grid2inner">
                            <div>
                                <label class="lbl">START DATE</label>
                                <div class="m-wrap"><input id="formStart" type="date" class="m-inp"></div>
                            </div>
                            <div>
                                <label class="lbl">ESTIMATED END</label>
                                <div class="m-wrap"><input id="formEnd" type="date" class="m-inp"></div>
                            </div>
                        </div>
                    </div>
                    <div>
                        <div class="secthead">
                            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 4.354a4 4 0 110 5.292M15 21H3v-1a6 6 0 0112 0v1zm0 0h6v-1a6 6 0 00-9-5.197M13 7a4 4 0 11-8 0 4 4 0 018 0z"></path></svg>
                            <span>STATUS</span>
                        </div>
                        <div class="grid2inner">
                            <div style="grid-column: span 2;">
                                <label class="lbl">CURRENT STATUS</label>
                                <select id="formStatus" class="m-inp">
                                    <option value="Ongoing">Ongoing</option>
                                    <option value="Completed">Completed</option>
                                    <option value="Terminated">Terminated</option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
            </div>

            <div class="sect">
                <div class="roadhead">
                    <div class="secthead" style="margin-bottom:0 !important;">
                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 20l-5.447-2.724A1 1 0 013 16.382V5.618a1 1 0 011.447-.894L9 7m0 13l6-3m-6 3V7m6 10l4.553 2.276A1 1 0 0021 18.382V7.618a1 1 0 00-.553-.894L15 4m0 13V4m0 0L9 7"></path></svg>
                        <span>AFFECTED ROADS SELECTION</span>
                    </div>
                    <button class="addbtn">
                        <svg width="14" height="14" fill="none" stroke="currentColor" viewBox="0 0 24 24" stroke-width="3"><path stroke-linecap="round" stroke-linejoin="round" d="M12 4v16m8-8H4"></path></svg>
                        ADD NEW ROAD TO SYSTEM
                    </button>
                </div>

                <div class="grid5">
                    <div class="roads">
                        <div class="m-wrap left">
                            <svg class="m-icon l" style="color:#cbd5e1;" width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"></path></svg>
                            <input type="text" placeholder="Search roads by name to add..." class="m-inp srch search-override">
                        </div>

                        <div class="list">
                            <div class="listtitle">SELECTED ASSETS (2)</div>
                            
                            <div class="item">
                                <div class="iteminfo">
                                    <div class="itembadge">
                                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"></path></svg>
                                    </div>
                                    <div>
                                        <div class="itemname">Nabunturan-Monkayo Arterial</div>
                                        <p class="itemdesc">Section: Km 24 - Km 28</p>
                                    </div>
                                </div>
                                <button class="del"><svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button>
                            </div>

                            <div class="item">
                                <div class="iteminfo">
                                    <div class="itembadge">
                                        <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M13.828 10.172a4 4 0 00-5.656 0l-4 4a4 4 0 105.656 5.656l1.102-1.101m-.758-4.899a4 4 0 005.656 0l4-4a4 4 0 00-5.656-5.656l-1.1 1.1"></path></svg>
                                    </div>
                                    <div>
                                        <div class="itemname">Poblacion Loop West</div>
                                        <p class="itemdesc">Section: Full length</p>
                                    </div>
                                </div>
                                <button class="del"><svg width="20" height="20" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16"></path></svg></button>
                            </div>
                        </div>
                    </div>

                    <div class="map">
                        <div class="expand">
                            <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 8V4m0 0h4M4 4l5 5m11-1V4m0 0h-4m4 0l-5 5M4 16v4m0 0h4m-4 0l5-5m11 5l-5-5m5 5v-4m0 4h-4"></path></svg>
                        </div>
                        <div class="pin">
                            <svg width="40" height="40" fill="currentColor" viewBox="0 0 20 20"><path fill-rule="evenodd" d="M5.05 4.05a7 7 0 119.9 9.9L10 18.9l-4.95-4.95a7 7 0 010-9.9zM10 11a2 2 0 100-4 2 2 0 000 4z" clip-rule="evenodd"></path></svg>
                        </div>
                        <div class="overlay">
                            <span>PREVIEW MODE</span>
                            <span class="link">Click to Expand</span>
                        </div>
                    </div>
                </div>
            </div>

            <div class="foot">
                <button id="cancelModalBtn" class="btn cancel">CANCEL</button>
                <button id="saveProjectBtn" class="btn save">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z"></path></svg>
                    <span>SAVE PROJECT ENTRY</span>
                </button>
                <button id="toggleEditBtn" class="btn save">
                    <svg width="16" height="16" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M15.232 5.232l3.536 3.536m-2.036-5.036a2.5 2.5 0 113.536 3.536L6.5 21.036H3v-3.572L16.732 3.732z"></path></svg>
                    <span>EDIT RECORD</span>
                </button>
            </div>
        </div>
    </div>

    <script type="module" src="Maintain.js"></script>

</body>
</html>