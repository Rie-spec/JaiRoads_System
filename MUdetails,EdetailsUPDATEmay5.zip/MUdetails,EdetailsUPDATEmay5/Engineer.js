// Engineer Module - JAIROADS
const firebaseConfig = {
    apiKey: "AIzaSyAMWkuployP7Vx0p7PpxE_UgwjqxmjuaIk",
    authDomain: "maintain-36ddd.firebaseapp.com",
    projectId: "maintain-36ddd",
    storageBucket: "maintain-36ddd.firebasestorage.app",
    messagingSenderId: "513735623640",
    appId: "1:513735623640:web:00f8e8cf0e4419fa1028ad"
};

// Initialize Firebase
if (!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig);
}
const db = firebase.firestore();

// Global State
window._engineerState = {
    allEngineers: [],
    filteredEngineers: [],
    currentPage: 1,
    rowsPerPage: 8,
    selectedEngineer: null
};

document.addEventListener('DOMContentLoaded', () => {
    initEngineerModule();
});

function initEngineerModule() {
    setupListeners();
    bindEvents();
    setupDetailsTabs();
    loadRanks(); // Dynamic ranks from DB if needed, or static
}

function setupListeners() {
    db.collection("engineers").onSnapshot(snapshot => {
        window._engineerState.allEngineers = snapshot.docs.map(doc => ({
            id: doc.id,
            ...doc.data()
        }));
        applyFilters();
    }, error => {
        console.error("Firestore Error:", error);
    });
}

function bindEvents() {
    const searchInput = document.getElementById('tableSearch');
    const rankFilter = document.getElementById('filterRank');
    const muniFilter = document.getElementById('filterMunicipality');
    const refreshBtn = document.getElementById('refreshBtn');
    const closeBtn = document.getElementById('closeEngineerDetailsBtn');

    searchInput?.addEventListener('input', () => {
        window._engineerState.currentPage = 1;
        applyFilters();
    });

    rankFilter?.addEventListener('change', () => {
        window._engineerState.currentPage = 1;
        applyFilters();
    });

    muniFilter?.addEventListener('change', () => {
        window._engineerState.currentPage = 1;
        applyFilters();
    });

    refreshBtn?.addEventListener('click', () => {
        searchInput.value = '';
        rankFilter.value = 'All';
        muniFilter.value = 'All';
        window._engineerState.currentPage = 1;
        applyFilters();
    });

    closeBtn?.addEventListener('click', closeDetailsModal);

    // Click outside to close
    document.getElementById('engineerDetailsModal')?.addEventListener('click', (e) => {
        if (e.target.id === 'engineerDetailsModal') closeDetailsModal();
    });
}

function applyFilters() {
    const searchTerm = document.getElementById('tableSearch')?.value.toLowerCase() || '';
    const selectedRank = document.getElementById('filterRank')?.value || 'All';
    const selectedMuni = document.getElementById('filterMunicipality')?.value || 'All';

    window._engineerState.filteredEngineers = window._engineerState.allEngineers.filter(eng => {
        const matchesSearch = (
            (eng.name?.toLowerCase().includes(searchTerm)) ||
            (eng.position?.toLowerCase().includes(searchTerm)) ||
            (eng.rank?.toLowerCase().includes(searchTerm))
        );
        const matchesRank = selectedRank === 'All' || eng.rank === selectedRank;
        const matchesMuni = selectedMuni === 'All' || eng.municipality === selectedMuni;

        return matchesSearch && matchesRank && matchesMuni;
    });

    renderTable();
}

function renderTable() {
    const recordsBody = document.getElementById('recordsBody');
    const { filteredEngineers, currentPage, rowsPerPage } = window._engineerState;

    if (!recordsBody) return;

    if (filteredEngineers.length === 0) {
        recordsBody.innerHTML = '<div class="records-placeholder">No engineers found matching your criteria.</div>';
        updatePaginationInfo(0);
        return;
    }

    const startIndex = (currentPage - 1) * rowsPerPage;
    const paginated = filteredEngineers.slice(startIndex, startIndex + rowsPerPage);

    recordsBody.innerHTML = paginated.map(eng => `
        <div class="record-row">
            <div class="head-col engineer-name-cell">
                <div class="engineer-avatar-mini">${getInitials(eng.name)}</div>
                <div style="font-weight: 700; color: #1e293b;">${eng.name || '---'}</div>
            </div>
            <div class="head-col">${eng.position || '---'}</div>
            <div class="head-col">
                <span class="rank-badge rank-${(eng.rank || 'Junior').toLowerCase()}">${eng.rank || 'Junior'}</span>
            </div>
            <div class="head-col">${eng.municipality || '---'}</div>
            <div class="col actions-col">
                <button type="button" class="action-btn view-btn" onclick="window.openEngineerDetails('${eng.id}')">
                    <i data-lucide="eye" style="width:20px; height:20px;"></i>
                </button>
            </div>
        </div>
    `).join('');

    updatePaginationInfo(filteredEngineers.length);
    if (window.lucide) lucide.createIcons();
}

function updatePaginationInfo(total) {
    const note = document.getElementById('recordsNote');
    const controls = document.getElementById('paginationControls');
    const { currentPage, rowsPerPage } = window._engineerState;

    const start = total === 0 ? 0 : (currentPage - 1) * rowsPerPage + 1;
    const end = Math.min(currentPage * rowsPerPage, total);
    
    if (note) note.innerText = `Showing ${start}-${end} of ${total} engineers`;

    if (!controls) return;
    
    const totalPages = Math.ceil(total / rowsPerPage);
    let html = '';
    
    // Simple pagination buttons
    if (totalPages > 1) {
        html += `<button class="page-btn" ${currentPage === 1 ? 'disabled' : ''} onclick="window.changeEngineerPage(${currentPage - 1})"><i data-lucide="chevron-left"></i></button>`;
        for(let i = 1; i <= totalPages; i++) {
            html += `<button class="page-btn ${i === currentPage ? 'active' : ''}" onclick="window.changeEngineerPage(${i})">${i}</button>`;
        }
        html += `<button class="page-btn" ${currentPage === totalPages ? 'disabled' : ''} onclick="window.changeEngineerPage(${currentPage + 1})"><i data-lucide="chevron-right"></i></button>`;
    }
    
    controls.innerHTML = html;
    if (window.lucide) lucide.createIcons();
}

window.changeEngineerPage = (page) => {
    window._engineerState.currentPage = page;
    renderTable();
};

window.openEngineerDetails = async (id) => {
    const eng = window._engineerState.allEngineers.find(e => e.id === id);
    if (!eng) return;

    window._engineerState.selectedEngineer = eng;
    const modal = document.getElementById('engineerDetailsModal');
    
    // Fill Data
    document.getElementById('detailName').innerText = eng.name || '---';
    document.getElementById('detailRank').innerText = eng.rank || '---';
    document.getElementById('detailEmail').innerText = eng.email || '---';
    document.getElementById('detailJoined').innerText = eng.memberSince || '---';
    document.getElementById('detailPosition').innerText = eng.position || '---';

    // Set active tab to 'all'
    const tabs = document.querySelectorAll('.engineer-details-modal .tab-btn');
    tabs.forEach(t => {
        t.classList.remove('active');
        if (t.dataset.filter === 'all') t.classList.add('active');
    });

    // Render History using the ID as the foreign key
    renderEngineerHistory(eng.id, 'all');

    if (modal) {
        modal.style.display = 'flex';
        modal.classList.add('active');
        document.body.style.overflow = 'hidden';
    }
    if (window.lucide) lucide.createIcons();
};

function setupDetailsTabs() {
    const tabs = document.querySelectorAll('.engineer-details-modal .tab-btn');
    tabs.forEach(btn => {
        btn.addEventListener('click', () => {
            tabs.forEach(t => t.classList.remove('active'));
            btn.classList.add('active');
            
            const filter = btn.dataset.filter;
            const eng = window._engineerState.selectedEngineer;
            
            // Re-run correlation query using the name
            if (eng && eng.name) renderEngineerHistory(eng.name, filter);
        });
    });
}

// Updated to accept engineerId instead of engineerName
async function renderEngineerHistory(engineerName, filter = 'all') {
    const historyList = document.getElementById('detailHistoryList');
    if (!historyList) return;

    historyList.innerHTML = '<div class="searching-spinner">Searching archives...</div>';

    try {
        // 3. THE LINK:
        // We query the "projects" collection looking for a string match
        // between "projects.engineer" and "engineers.name"
        let query = db.collection("projects").where("engineer", "==", engineerName);
        
        if (filter !== 'all') {
            const status = filter.charAt(0).toUpperCase() + filter.slice(1);
            query = query.where("status", "==", status);
        }

        const projectsSnap = await query.orderBy("title").limit(10).get();
        
        if (projectsSnap.empty) {
            historyList.innerHTML = '<div class="empty-state">No matching projects found for this name.</div>';
            return;
        }

        historyList.innerHTML = projectsSnap.docs.map(doc => {
            const p = doc.data();
            const status = (p.status || 'Ongoing').toLowerCase();
            return `
                <div class="history-item-row">
                    <div>
                        <div class="h-title">${p.title || 'Untitled Project'}</div>
                        <div class="h-meta-row">
                            <span>${p.municipality || 'Davao de Oro'}</span>
                            <span>•</span>
                            <span>₱${Number(p.budget || 0).toLocaleString()}</span>
                        </div>
                    </div>
                    <span class="status-badge status-${status}">${p.status || 'Ongoing'}</span>
                </div>
            `;
        }).join('');

    } catch (err) {
        console.error("Correlation Error:", err);
        historyList.innerHTML = '<div class="empty-state">Error correlating project data.</div>';
    }
}

function closeDetailsModal() {
    const modal = document.getElementById('engineerDetailsModal');
    if (modal) {
        modal.style.display = 'none';
        modal.classList.remove('active');
        document.body.style.overflow = 'auto';
    }
}

function getInitials(name) {
    if (!name) return '??';
    return name.split(' ').map(n => n[0]).join('').toUpperCase().substring(0, 2);
}

function loadRanks() {
    // Dynamic loading of ranks could be here, but static is fine for now
}