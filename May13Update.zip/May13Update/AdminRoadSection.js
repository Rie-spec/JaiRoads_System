import { initializeApp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-app.js";
import { getFirestore, collection, addDoc, onSnapshot, deleteDoc, doc, updateDoc, query, orderBy, where, serverTimestamp } from "https://www.gstatic.com/firebasejs/10.8.1/firebase-firestore.js";

const firebaseConfig = {
    apiKey: "AIzaSyAMWkuployP7Vx0p7PpxE_UgwjqxmjuaIk",
    authDomain: "maintain-36ddd.firebaseapp.com",
    projectId: "maintain-36ddd",
    storageBucket: "maintain-36ddd.firebasestorage.app",
    messagingSenderId: "513735623640",
    appId: "1:513735623640:web:00f8e8cf0e4419fa1028ad"
};

// Global State
window._roadState = window._roadState || {
    allRoads: [],
    filteredRoads: [],
    currentPage: 1,
    currentRoadId: null
};

const itemsPerPage = 8;
let drawingMap = null;
let previewMap = null;
let db;

try {
    const app = initializeApp(firebaseConfig);
    db = getFirestore(app);
} catch (err) {
    console.error('Firebase failed to initialize:', err);
}

const getFormOverlay = () => document.getElementById('roadFormModal');
const getDetailsOverlay = () => document.getElementById('roadDetailsModal');
const getTableBody = () => document.getElementById('roadsTableBody');

// --- EVENT DELEGATION ---
const setupDelegation = () => {
    const handler = (e) => {
        // Open Modal (Add)
        if (e.target.closest('#btnAddNewRoad')) {
            openRoadForm();
        }

        // Close Modals
        if (e.target.closest('#btnCloseRoadForm, #btnCancelRoadForm, #btnCloseRoadDetails')) {
            closeModals();
        }

        // Edit via Details
        if (e.target.closest('#btnEditRoadFromDetails')) {
            const id = window._roadState.currentRoadId;
            const road = window._roadState.allRoads.find(r => r.id === id);
            if (road) {
                closeModals();
                setTimeout(() => openRoadForm(road), 350);
            }
        }

        // Mapping Mode Selection
        const startBtn = e.target.closest('#btnSetStart');
        if (startBtn) {
            setMappingMode('start', startBtn);
        }

        const endBtn = e.target.closest('#btnSetEnd');
        if (endBtn) {
            setMappingMode('end', endBtn);
        }

        // Fullscreen Logic
        const fsBtn = e.target.closest('#btnFullscreenMap');
        if (fsBtn) {
            toggleFullscreen(fsBtn.closest('.map-wrapper'));
        }

        // Refresh
        const refreshBtn = e.target.closest('#refreshBtn');
        if (refreshBtn) {
            animateRefresh(refreshBtn);
            applyFilters();
        }

        // Table Actions
        const viewBtn = e.target.closest('.view-btn');
        if (viewBtn) {
            const id = viewBtn.dataset.id;
            window.viewRecord(id);
        }
    };

    document.addEventListener('click', handler);
};

setupDelegation();

// --- HELPERS ---
function setMappingMode(mode, btn) {
    window._addingMode = mode;
    const mapEl = document.getElementById('drawingMap');
    if (mapEl) mapEl.style.cursor = 'crosshair';
    
    const guidance = document.getElementById('missionGuidance');
    if (guidance) guidance.innerText = `MISSION: SELECT ROAD ${mode.toUpperCase()} POINT...`;
    
    document.querySelectorAll('.btn-terminal-action').forEach(b => b.classList.remove('active'));
    btn.classList.add('active');
}

function animateRefresh(btn) {
    const icon = btn.querySelector('svg');
    if (icon) {
        const currentRot = (parseInt(btn.dataset.rotation || '0')) + 360;
        btn.dataset.rotation = currentRot;
        icon.style.transition = 'transform 0.6s cubic-bezier(0.4, 0, 0.2, 1)';
        icon.style.transform = `rotate(${currentRot}deg)`;
    }
}

function toggleFullscreen(wrapper) {
    if (!document.fullscreenElement) {
        wrapper.requestFullscreen().then(() => {
            wrapper.classList.add('roads-map-fullscreen');
        }).catch(err => console.error(err));
    } else {
        document.exitFullscreen();
    }
}

document.addEventListener('fullscreenchange', () => {
    if (!document.fullscreenElement) {
        document.querySelectorAll('.map-wrapper').forEach(w => w.classList.remove('roads-map-fullscreen'));
    }
});

// --- MAP LOGIC ---
const mapClickListener = (e) => {
    if (!window._addingMode || window._addingMode === 'none') return;

    if (window._addingMode === 'start') {
        if (window._startMarker) drawingMap.removeLayer(window._startMarker);
        window._startMarker = L.marker(e.latlng, { draggable: true }).addTo(drawingMap);
        window._startMarker.on('dragend', updateRoute);
        
        // Optional: Auto-focus the next button or just stay in mode
        document.getElementById('missionGuidance').innerText = "START POINT CAPTURED. NOW SET END POINT.";
    } 
    else if (window._addingMode === 'end') {
        if (window._endMarker) drawingMap.removeLayer(window._endMarker);
        window._endMarker = L.marker(e.latlng, { draggable: true }).addTo(drawingMap);
        window._endMarker.on('dragend', updateRoute);
        
        document.getElementById('missionGuidance').innerText = "POINTS CAPTURED. YOU CAN DRAG THEM TO ADJUST.";
    }

    // Keep the mode active or reset it? 
    // Resetting it (as you did) is safer to prevent accidental clicks.
    window._addingMode = 'none'; 
    document.getElementById('drawingMap').style.cursor = 'grab';
    document.querySelectorAll('.btn-terminal-action').forEach(b => b.classList.remove('active'));
    
    updateRoute();
};

function updateRoute() {
    const start = window._startMarker;
    const end = window._endMarker;
    if (start && end) {
        if (window._routingControl) drawingMap.removeControl(window._routingControl);
        
        window._routingControl = L.Routing.control({
            waypoints: [start.getLatLng(), end.getLatLng()],
            addWaypoints: false,
            draggableWaypoints: false,
            lineOptions: { styles: [{ color: '#78350F', opacity: 0.8, weight: 6 }] },
            show: false,
            createMarker: () => null
        }).addTo(drawingMap);

        window._routingControl.on('routesfound', (e) => {
            const route = e.routes[0];
            const distanceKm = (route.summary.totalDistance / 1000).toFixed(2);
            const geoJSON = {
                type: 'Feature',
                geometry: {
                    type: 'LineString',
                    coordinates: route.coordinates.map(c => [c.lng, c.lat])
                },
                properties: { distance: route.summary.totalDistance, updatedAt: new Date().toISOString() }
            };
            document.getElementById('roadGeoJSON').value = JSON.stringify(geoJSON);
            document.getElementById('totalDistance').innerText = `${distanceKm} km`;
            document.getElementById('missionGuidance').innerText = `TERMINAL: ${distanceKm}KM CAPTURED`;
            document.getElementById('geojsonStatusText').innerText = `Route captured: ${distanceKm} km`;
            document.getElementById('geojsonStatus').classList.add('success');
            
            const container = document.querySelector('.leaflet-routing-container');
            if (container) container.style.display = 'none';
        });
    }
}

// --- FIRESTORE ---
const initFirestore = () => {
    if (!db) return;
    onSnapshot(collection(db, "roads"), (snapshot) => {
        window._roadState.allRoads = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
        applyFilters();
    });
};

initFirestore();

function applyFilters() {
    const muni = document.getElementById('filterMunicipality')?.value || "All";
    const state = document.getElementById('filterStateCategory')?.value || "All";
    const pave = document.getElementById('filterPavement')?.value || "All";
    const sort = document.getElementById('filterSort')?.value || "Newest First";
    const search = document.getElementById('roadSearch')?.value.toLowerCase() || "";

    window._roadState.filteredRoads = window._roadState.allRoads.filter(r => {
    const matchMuni = muni === "All" || r.municipality === muni;
    const matchState = state === "All" || r.stateCategory === state;
    const matchPave = pave === "All" || r.pavementType === pave;

    // IMPROVED SEARCH: Check start OR end individually
    const searchTerm = search.toLowerCase();
    const matchSearch = searchTerm === "" || 
                        (r.start || "").toLowerCase().includes(searchTerm) || 
                        (r.end || "").toLowerCase().includes(searchTerm);

    return matchMuni && matchState && matchPave && matchSearch;
});

    window._roadState.filteredRoads.sort((a, b) => {
        const dateA = a.createdAt?.toDate?.() || a.createdAt || 0;
        const dateB = b.createdAt?.toDate?.() || b.createdAt || 0;
        const roadA = `${a.start} - ${a.end}`;
        const roadB = `${b.start} - ${b.end}`;
        if (sort === "A-Z") return roadA.localeCompare(roadB);
        if (sort === "Oldest First") return dateA - dateB;
        return dateB - dateA;
    });

    window._roadState.currentPage = 1;
    renderTable();
}

['filterMunicipality', 'filterStateCategory', 'filterPavement', 'filterSort'].forEach(id => {
    document.getElementById(id)?.addEventListener('change', applyFilters);
});
document.getElementById('roadSearch')?.addEventListener('input', applyFilters);

function renderTable() {
    const body = getTableBody();
    if (!body) return;
    body.innerHTML = '';

    const { filteredRoads, currentPage } = window._roadState;
    if (filteredRoads.length === 0) {
        body.innerHTML = `<div class="records-placeholder">No road segments found.</div>`;
        document.getElementById('recordsNote').innerText = 'Showing 0 roads';
        return;
    }

    const start = (currentPage - 1) * itemsPerPage;
    const paginated = filteredRoads.slice(start, start + itemsPerPage);

    paginated.forEach(road => {
        const row = document.createElement('div');
        row.className = 'record-row';
        row.style.gridTemplateColumns = "2fr 1fr 1fr 1fr 1fr 100px";

        const stateColor = road.stateCategory === 'Good' ? '#059669' : (road.stateCategory === 'Fair' ? '#d97706' : '#dc2626');

        row.innerHTML = `
            <div class="col">
                <div class="road-name-main">
                    ${road.start} - ${road.end}
                </div>
                <div class="road-id-sub">SEC-${road.id.substring(0, 8).toUpperCase()}</div>
            </div>
            <div class="col font-medium" style="font-size: 14px; color: #334155;">${road.municipality}</div>
            <div class="col" style="font-weight: 800; color: ${stateColor}; font-size: 14px;">
                ${road.stateCategory || '---'}
            </div>
            <div class="col font-medium" style="font-size: 14px; color: #334155;">
                ${road.pavementType || '---'}
            </div>
            <div class="col">
                <div class="spatial-badge">
                   <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5"><polyline points="22 12 18 12 15 21 9 3 6 12 2 12"></polyline></svg>
                   Captured
                </div>
            </div>
            <div class="col actions-col" style="text-align: right;">
                <button type="button" class="action-btn view-btn" data-id="${road.id}" title="View Details">
                    <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"></path><circle cx="12" cy="12" r="3"></circle></svg>
                </button>
            </div>
        `;
        body.appendChild(row);
    });

    const actualEnd = Math.min(start + itemsPerPage, filteredRoads.length);
    document.getElementById('recordsNote').innerText = `Showing ${start + 1}-${actualEnd} of ${filteredRoads.length} sections`;
}

// --- MODALS ---
function closeModals() {
    const form = getFormOverlay();
    const details = getDetailsOverlay();
    if (form) form.classList.remove('active');
    if (details) details.classList.remove('active');
    document.body.classList.remove('modal-open');
    setTimeout(() => {
        if (form) form.style.display = 'none';
        if (details) details.style.display = 'none';
    }, 300);
}

function openRoadForm(road = null) {
    const formOverlay = getFormOverlay();
    if (!formOverlay) return;

    window._roadState.currentRoadId = road ? road.id : null;
    const form = document.getElementById('roadForm');
    form.reset();
    
    document.getElementById('geojsonStatusText').innerText = 'No road geometry captured yet';
    document.getElementById('geojsonStatus').classList.remove('success');
    document.getElementById('roadGeoJSON').value = '';
    document.getElementById('roadFormTitle').innerText = road ? "EDIT ROAD SECTION" : "NEW ROAD SECTION RECORD";

    if (road) {
        document.getElementById('roadStart').value = road.start || '';
        document.getElementById('roadEnd').value = road.end || '';
        document.getElementById('roadMunicipality').value = road.municipality;
        document.getElementById('pavementType').value = road.pavementType;
        document.getElementById('stateCategory').value = road.stateCategory || '';
        document.getElementById('roadGeoJSON').value = road.geoJSON || '';
        document.getElementById('geojsonStatusText').innerText = 'Geometry loaded from database';
        document.getElementById('geojsonStatus').classList.add('success');
    }

    formOverlay.style.display = 'flex';
    setTimeout(() => {
        formOverlay.classList.add('active');
        document.body.classList.add('modal-open');
        initDrawingMap(road);
    }, 10);
}

function initDrawingMap(road) {
    if (!drawingMap) {
        drawingMap = L.map('drawingMap').setView([7.6044, 125.9522], 11);
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(drawingMap);
        drawingMap.on('click', mapClickListener);
        drawingMap.on('mousemove', (e) => {
            document.getElementById('currentLat').innerText = e.latlng.lat.toFixed(6);
            document.getElementById('currentLng').innerText = e.latlng.lng.toFixed(6);
        });
    }

    // Reset markers
    if (window._startMarker) drawingMap.removeLayer(window._startMarker);
    if (window._endMarker) drawingMap.removeLayer(window._endMarker);
    if (window._routingControl) drawingMap.removeControl(window._routingControl);
    
    window._startMarker = null;
    window._endMarker = null;
    window._routingControl = null;
    window._addingMode = 'none';
    document.getElementById('drawingMap').style.cursor = 'grab';
    document.getElementById('totalDistance').innerText = `0.00 km`;

    if (road && road.geoJSON) {
        try {
            const geo = JSON.parse(road.geoJSON);
            const coords = geo.geometry.coordinates;
            const start = [coords[0][1], coords[0][0]];
            const end = [coords[coords.length-1][1], coords[coords.length-1][0]];
            window._startMarker = L.marker(start, { draggable: true }).addTo(drawingMap);
            window._endMarker = L.marker(end, { draggable: true }).addTo(drawingMap);
            window._startMarker.on('dragend', updateRoute);
            window._endMarker.on('dragend', updateRoute);
            updateRoute();
            setTimeout(() => {
                drawingMap.invalidateSize();
                drawingMap.fitBounds([start, end], { padding: [50, 50] });
            }, 100);
        } catch (e) {
            console.error(e);
        }
    } else {
        setTimeout(() => drawingMap.invalidateSize(), 100);
    }
}

window.viewRecord = (id) => {
    const road = window._roadState.allRoads.find(r => r.id === id);
    if (!road) return;
    window._roadState.currentRoadId = id;

    // Set Text Values
    const roadNameEl = document.getElementById('viewRoadName_text');
    if (roadNameEl) roadNameEl.innerText = `${road.start} - ${road.end}`;

    const muniEl = document.getElementById('viewMunicipality_bold');
    if (muniEl) muniEl.innerText = road.municipality || '---';

    const paveEl = document.getElementById('viewPavementType_bold');
    if (paveEl) paveEl.innerText = road.pavementType || '---';

    // State Badge Logic
    const stateBadge = document.getElementById('viewStateBadge');
    if (stateBadge) {
        const cat = road.stateCategory || 'Good';
        stateBadge.innerText = cat.toUpperCase();
        
        // Dynamic Color classes or inline
        let bg, text;
        if (cat === 'Good') { bg = '#ecfdf5'; text = '#059669'; }
        else if (cat === 'Fair') { bg = '#fffbeb'; text = '#d97706'; }
        else { bg = '#fef2f2'; text = '#dc2626'; }
        
        stateBadge.style.backgroundColor = bg;
        stateBadge.style.color = text;
    }

    // Combined Uploaded/Edited Dates
    let addDate = "--";
    if (road.createdAt) {
        let d = road.createdAt;
        if (d.toDate) d = d.toDate();
        addDate = new Date(d).toLocaleDateString('en-US', { month: 'long', day: 'numeric', year: 'numeric' });
    }
    const createMeta = document.getElementById('viewCreatedAt_meta');
    if (createMeta) createMeta.innerText = `Uploaded: ${addDate}`;

    const creatorEl = document.getElementById('metaCreator');
    if (creatorEl) creatorEl.innerText = `Created by: ${road.createdBy || 'District Engineer'}`;

    const editedEl = document.getElementById('metaLastEdited');
    if (editedEl) {
        let editDate = "N/A";
        if (road.updatedAt) {
            let uD = road.updatedAt;
            if (uD.toDate) uD = uD.toDate();
            editDate = new Date(uD).toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
        }
        editedEl.innerText = `Edited: ${editDate}`;
    }

    const overlay = getDetailsOverlay();
    overlay.style.display = 'flex';
    setTimeout(() => {
        overlay.classList.add('active');
        document.body.classList.add('modal-open');
        initPreviewMap(road);
    }, 10);
};

function initPreviewMap(road) {
    // Ported strictly from MPDetails logic
    setTimeout(() => {
        if (window._detailsMap) window._detailsMap.remove();
        
        window._detailsMap = L.map('previewMap', { 
            zoomControl: false, 
            attributionControl: false 
        }).setView([7.6, 125.7], 12);

        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png').addTo(window._detailsMap);
        
        const group = L.featureGroup();
        
        if (road.geoJSON) {
            try {
                const l = L.geoJSON(JSON.parse(road.geoJSON), { 
                    style: { color: '#78350F', weight: 6 } 
                }).addTo(window._detailsMap);
                group.addLayer(l);
            } catch (e) {
                console.error("GeoJSON Parse Error:", e);
            }
        }

        if (group.getLayers().length > 0) {
            const bounds = group.getBounds();
            window._detailsMap.fitBounds(bounds, { padding: [30, 30] });
            
            // Lock to preview: Set max bounds with 150% padding (increased for more movement) and set min zoom
            const paddedBounds = bounds.pad(1.5);
            window._detailsMap.setMaxBounds(paddedBounds);
            window._detailsMap.setMinZoom(window._detailsMap.getBoundsZoom(paddedBounds) - 1);
            
            window._detailsMap.on('drag', function() {
                window._detailsMap.panInsideBounds(paddedBounds, { animate: false });
            });
        }
    }, 100);
}

// 1. Use Delegation: Attach to document, not the specific ID
document.addEventListener('submit', async (e) => {
    // Only run if the submitted form is our roadForm
    if (e.target && e.target.id === 'roadForm') {
        e.preventDefault();
        
        const btn = document.getElementById('btnSaveRoad');
        const btnText = document.getElementById('btnSaveText'); // In case you have a text span

        // 2. Defensive Value Fetching
        const getVal = (id) => document.getElementById(id)?.value?.trim() || "";

        const geoJSONRaw = getVal('roadGeoJSON');
        const start = getVal('roadStart');
        const end = getVal('roadEnd');
        const municipality = getVal('roadMunicipality');
        const pavementType = getVal('pavementType');
        const stateCategory = getVal('stateCategory');

        // 3. Validation
        if (!geoJSONRaw) {
            alert("⚠️ MAPPING ERROR: Please select Start and End points on the map.");
            return;
        }

        if (!start || !end) {
            alert("⚠️ MISSING DATA: Please enter both Start and End names.");
            return;
        }

        // Inside your submit listener:
    const data = {
    start: document.getElementById('roadStart').value.trim(),
    end: document.getElementById('roadEnd').value.trim(),
    municipality: document.getElementById('roadMunicipality').value,
    pavementType: document.getElementById('pavementType').value,
    stateCategory: document.getElementById('stateCategory').value,
    geoJSON: document.getElementById('roadGeoJSON').value, 
    updatedAt: serverTimestamp()
};

// CRITICAL VALIDATION: 
// If geoJSON is empty, the map routing failed or wasn't finished.
if (!data.geoJSON || data.geoJSON === "") {
    alert("⚠️ Please select BOTH start and end points on the map until a route appears.");
    return;
}

        try {
            if (btn) btn.disabled = true;
            if (btnText) btnText.innerText = "SAVING...";

            if (window._roadState.currentRoadId) {
                // UPDATE EXISTING
                await updateDoc(
                    doc(db, "roads", window._roadState.currentRoadId),
                    data
                );
                console.log("Document updated successfully");
            } else {
                // CREATE NEW
                data.createdAt = serverTimestamp();
                data.createdBy = "District Engineer";
                await addDoc(collection(db, "roads"), data);
                console.log("Document created successfully");
            }

            alert("✅ ASSET SAVED SUCCESSFULLY");
            closeModals();

        } catch (err) {
            console.error("Firestore Save Error:", err);
            alert("❌ SAVE FAILED: " + err.message);
        } finally {
            if (btn) btn.disabled = false;
            if (btnText) btnText.innerText = "SAVE ROAD ASSET";
        }
    }
});